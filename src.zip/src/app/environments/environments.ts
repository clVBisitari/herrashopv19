export const environment = {
     api_url : "http://localhost:3000/api",  
     prod: true
};